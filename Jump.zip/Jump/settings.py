import os

TITLE = "Jump!"
FPS = 60

cloudVelocity = -0.5
acceleration = 0.001

CUR_PATH = os.path.dirname(__file__)

muting = False

grey = (50,50,50)
jaune1 = (248, 253, 148)
jaune1HEX = "#F8FD94"
jaune2 = (236, 186, 0)
jaune2HEX = "#ECBA00"
jaune3 = (255, 217, 75)
blanc = (200, 200, 200)

listOfKeys = ["A","B","C","D","E","F","G","H","I","J",
"K","L","M","N","O","P","Q","R","S","T",
"U","V","W","X","Y","Z"]